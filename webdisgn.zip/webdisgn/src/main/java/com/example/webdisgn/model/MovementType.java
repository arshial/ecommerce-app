package com.example.webdisgn.model;

public enum MovementType {
    IN, OUT
}
