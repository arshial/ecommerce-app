package com.example.webdisgn.dto.response;

import lombok.Data;

@Data
public class UserResponse {
    private String id;
    private String name;
    private String email;
}
