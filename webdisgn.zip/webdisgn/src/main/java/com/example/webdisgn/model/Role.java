package com.example.webdisgn.model;

public enum Role {
    USER,
    ADMIN,
    MODERATOR,
    SUPPORT
}
