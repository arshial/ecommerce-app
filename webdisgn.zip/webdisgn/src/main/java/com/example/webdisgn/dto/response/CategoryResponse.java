package com.example.webdisgn.dto.response;

import lombok.Data;

@Data
public class CategoryResponse {
    private String id;
    private String name;
    private String description;
}
