package com.example.webdisgn.model;

public enum DiscountType {
    PERCENTAGE,
    FIXED
}
