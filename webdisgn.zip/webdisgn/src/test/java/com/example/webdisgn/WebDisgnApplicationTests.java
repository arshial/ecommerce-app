package com.example.webdisgn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebDisgnApplicationTests {

    @Test
    void contextLoads() {
    }
}
